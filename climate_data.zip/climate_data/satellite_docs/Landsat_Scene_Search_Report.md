# Landsat Scene Search Report

## Scope
This report documents the search for real Landsat scenes for the Bangladesh study areas:

- Dhaka
- Satkhira
- Sunamganj
- Bhola

The approximate coordinates used were taken from the project file `Locations.csv`.

## Official sources reviewed
The following official USGS and NASA sources were reviewed:

- https://earthexplorer.usgs.gov/
- https://www.usgs.gov/landsat-missions/landsat-data-access
- https://www.usgs.gov/landsat-missions/landsat-collection-2
- https://m2m.cr.usgs.gov/

## Verified facts from official sources
The official USGS pages confirm that:

- EarthExplorer is an official USGS application for Landsat scene search and download.
- USGS Landsat data access includes Level-1 and Level-2 products.
- Landsat Collection 2 is the official archive structure for current Landsat products.
- The M2M API provides programmatic access to Landsat datasets.
- Landsat data are available for historical and recent scenes, but scene availability depends on the date, product, location, and archive status.

## Access limitation
In this environment, the official USGS EarthExplorer search and M2M archive interface were not accessible for authenticated scene retrieval. Because no authenticated session or direct archive query was available, no real scene metadata could be retrieved from the authoritative source.

This means that no Landsat scene records in this project can be marked as VERIFIED from the archive itself.

## Study area coordinates used
| Location | Latitude | Longitude | Notes |
|---|---:|---:|---|
| Dhaka | 23.8103 | 90.4125 | Approximate city-center coordinate |
| Satkhira | 22.7185 | 89.0705 | Approximate city-center coordinate |
| Bhola | 22.6859 | 90.6482 | Approximate city-center coordinate |
| Sunamganj | 25.0658 | 91.3950 | Approximate city-center coordinate |

## Search result
The search result is:

- Verified scenes: 0
- Unverified candidate scenes: 0
- Not available in this environment: 4 study areas pending archive access

## Why no scene metadata was accepted as verified
The task requires a real scene record to include:

- Satellite name
- Sensor name
- Product identifier
- Collection and processing level
- Acquisition date
- WRS path and row
- Cloud cover percentage
- Spatial resolution
- Official source URL
- Verification status

None of those values could be retrieved from an authoritative source during this phase. Because of this, the project must not fabricate or infer any scene metadata.

## Safe status
### VERIFIED
None.

### UNVERIFIED
None accepted.

### NOT AVAILABLE / PENDING AUTHENTICATED ARCHIVE ACCESS
- Dhaka candidate scene search
- Satkhira candidate scene search
- Sunamganj candidate scene search
- Bhola candidate scene search

## Recommended next step
A real scene search should be performed with an authenticated USGS EarthExplorer or M2M session. After that, the collection can be filled with genuine Landsat scene metadata for a limited set of before/after dates.

## Scientific note
For a project like this, scene selection should be based on actual archive metadata, including date, cloud cover, season, sensor compatibility, and product level. Without archive access, any scene-specific claim would be unverified and scientifically weak.
