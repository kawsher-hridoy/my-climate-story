# Satellite Developer Implementation Notes

## Goal
This document explains the most practical official satellite data sources for a beginner-friendly before-and-after feature in Bangladesh.

## Recommended data strategy
For a time-series compare feature, the best official source is:

- USGS Landsat Collection 2 Level-2 surface reflectance via EarthExplorer or the M2M API

This is preferred over NASA GIBS for historical comparison because it is scene-based, searchable by date and region, and designed for Earth observation analysis.

## Why GIBS is still useful
GIBS is helpful for:
- browser-based map overlays
- quick global imagery previews
- educational or display-only visualizations

GIBS is less ideal for:
- long-term before-and-after change detection across exact Bangladesh locations
- custom scene selection and archival download workflows

## Why Landsat is better for this project
The USGS Landsat archive supports:
- multi-year historical comparison
- land-cover change detection
- scene-based selection by date and location
- official satellite archive access

For the proposed use cases, these are the strongest matches:
- Dhaka urban expansion
- Satkhira coastal change
- Sunamganj wetland change
- Bhola river and coastal changes

## Suggested workflow
1. Use EarthExplorer to search Landsat scenes for each study area.
2. Filter by date range and cloud cover.
3. Select a before date and an after date.
4. Download the relevant Landsat Collection 2 scene(s).
5. Use a simple visualization layer or a quick local image comparison tool.
6. Avoid mixing different seasonal windows without documenting the season.

## Beginner caution
Do not assume the same years or cloud-free conditions exist for every location. A historical Landsat scene may be available, but it may be clouded or not ideal for interpretation. A date must be checked in the official archive before being used in project documentation.

## Code concept for a Leaflet map with a NASA GIBS layer
```javascript
const map = L.map('map').setView([23.7, 90.4], 7);

L.tileLayer('https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/MODIS_Terra_CorrectedReflectance_TrueColor/default/2024-01-01/EPSG3857_250m/{z}/{y}/{x}.jpg', {
  attribution: 'NASA GIBS',
  maxZoom: 12
}).addTo(map);
```

This example is for display and should not be treated as a complete historical change-detection workflow.

## Data source hierarchy for the project
1. Official USGS Landsat archive for historical before-and-after analysis
2. NASA GIBS for quick map display and basemap context
3. Additional project-specific scene checks for Bangladesh coordinates and date windows

## Verification status
These recommendations are grounded in the official NASA and USGS documentation. Exact scene IDs, local cloud cover, and date-by-location availability still need to be checked in the selected official archive tools before finaling a project dataset.
