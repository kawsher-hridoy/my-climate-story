# Data Inventory for My Climate Story

## Scope
This inventory covers the core datasets currently present in the project package and distinguishes:

- collected and validated data
- collected but not fully validated data
- missing or incomplete data
- developer implementation inputs

## 1) Project datasets present

### A. Location reference data
1. `Locations.csv`
   - Status: Collected and usable
   - Contents: 12 Bangladesh locations with approximate city-center coordinates
   - Source: project-created reference list, not an official NASA dataset
   - Use: map selection and API query routing
   - Important: coordinates are approximate, not official administrative boundaries

### B. NASA POWER data
2. `downloaded_data/NASA_POWER_dhaka.json`
   - Status: Collected and validated for units metadata
   - Source: NASA POWER monthly API
   - Use: local example and metadata reference for parameter units

3. `downloaded_data/NASA_POWER_<location>.json`
   - Status: Collected for multiple Bangladesh locations
   - Data included: barishal, bhola, chattogram, coxs_bazar, dhaka, khulna, mymensingh, rajshahi, rangpur, satkhira, sunamganj, sylhet
   - Source: NASA POWER monthly API
   - Use: local monthly historical climate context by location

4. `downloaded_data/Bangladesh_Monthly_Climate_Data.csv`
   - Status: Collected and processed from NASA POWER source files
   - Source: NASA POWER combined monthly file
   - Use: developer dataset for climate chart input

5. `cleaned_data/Bangladesh_Clean_Monthly_Data.csv`
   - Status: Cleaned and validated for monthly records
   - Source: NASA POWER + cleaning workflow
   - Use: monthly charting dataset

6. `cleaned_data/Bangladesh_Annual_Summary.csv`
   - Status: Cleaned and validated for annual records
   - Source: NASA POWER + annual aggregation
   - Use: annual summary charts and feature summaries

7. `cleaned_data/Data_Quality_Report.txt`
   - Status: Validated quality report available
   - Contents: metrics and notes for cleaned POWER datasets

### C. GISTEMP global climate context
8. `downloaded_data/Global_Temperature_Data_GISTEMP.csv`
   - Status: Collected and inspected
   - Source: NASA GISS GISTEMP
   - Use: global temperature anomaly context only
   - Important: not local Bangladesh temperature

9. `gistemp_processed/Global_Temperature_Annual_Clean.csv`
   - Status: Processed and validated
   - Use: annual global anomaly chart

10. `gistemp_processed/Global_Temperature_Monthly_Clean.csv`
   - Status: Processed and validated
   - Use: monthly global anomaly chart

11. `gistemp_processed/GISTEMP_Data_Quality_Report.txt`
   - Status: Processed and documented

12. `gistemp_processed/GISTEMP_Developer_Guide.md`
   - Status: Developer-ready documentation

### D. NASA documentation and metadata
13. `NASA_Data_Units.md`
   - Status: Updated and verified against NASA POWER JSON metadata
   - Use: unit documentation for POWER parameters

14. `API_Links.txt`
   - Status: Collected and usable
   - Source references: NASA POWER, GISTEMP, GIBS, NASA Sea Level Change, NASA NEX-GDDP-CMIP6

15. `README.md`
   - Status: Collected and informative
   - Use: project starter documentation

### E. Satellite imagery references
16. `satellite_data/NASA_GIBS_API_Guide.md`
   - Status: Documented research summary
   - Use: GIBS integration planning only

17. `satellite_data/Landsat_Historical_Data_Guide.md`
   - Status: Documented research summary
   - Use: Landsat access planning

18. `satellite_data/Satellite_Data_Sources.csv`
   - Status: Source catalog for official references

19. `satellite_data/Satellite_Developer_Implementation.md`
   - Status: Implementation guidance only

20. `satellite_data/Satellite_Data_Validation_Report.md`
   - Status: Research validation notes

21. `satellite_data/Bangladesh_Landsat_Scene_Catalog.csv`
   - Status: Empty catalog with headers only
   - Meaning: no real scene metadata verified yet

22. `satellite_data/Landsat_Scene_Search_Report.md`
   - Status: Access limitation documented
   - Meaning: no scene metadata could be verified without USGS archive access

23. `satellite_data/Satellite_Comparison_Plan.md`
   - Status: Prepared as a future workflow guide

## 2) Datasets successfully collected and validated
These are ready for project use in a scientific and developer handoff sense:

- `Locations.csv`
- NASA POWER monthly JSON files for Bangladesh locations
- `downloaded_data/Bangladesh_Monthly_Climate_Data.csv`
- `cleaned_data/Bangladesh_Clean_Monthly_Data.csv`
- `cleaned_data/Bangladesh_Annual_Summary.csv`
- `downloaded_data/Global_Temperature_Data_GISTEMP.csv`
- `gistemp_processed/Global_Temperature_Annual_Clean.csv`
- `gistemp_processed/Global_Temperature_Monthly_Clean.csv`
- `NASA_Data_Units.md`
- `API_Links.txt`

## 3) Datasets missing or incomplete
These are incomplete or not yet scientifically verified:

- Real Landsat scenes for Dhaka, Satkhira, Sunamganj, and Bhola
- Real satellite image download files or processed geospatial scenes
- A verified before-and-after Landsat inventory with cloud cover, product ID, path/row, and date metadata
- Any developer-ready imagery comparison dataset that requires actual USGS archive access

## 4) Official source documentation references
Official sources used or cited in the project:

- NASA POWER: https://power.larc.nasa.gov/docs/services/api/
- NASA GISTEMP: https://data.giss.nasa.gov/gistemp/
- NASA GIBS: https://nasa-gibs.github.io/gibs-api-docs/access-basics/
- USGS Landsat data access: https://www.usgs.gov/landsat-missions/landsat-data-access
- USGS Landsat Collection 2: https://www.usgs.gov/landsat-missions/landsat-collection-2
- USGS M2M API: https://m2m.cr.usgs.gov/
- USGS EarthExplorer: https://earthexplorer.usgs.gov/

## 5) Feature fit by dataset
- Local climate line charts: NASA POWER monthly/annual CSVs
- Global context chart: GISTEMP processed CSVs
- Map selection and city coordinates: `Locations.csv`
- Historical and recent local imagery comparison: requires real Landsat scene acquisition and processing; not ready
- General imagery map display: NASA GIBS docs and layer references, but not a verified Bangladesh scene archive yet

## 6) Data collection vs developer implementation
Data collection responsibilities:
- gather official source files and metadata
- verify units, missing values, and date structure
- document source limitations and missing data
- preserve original NASA files unchanged
- prepare clean versions for handoff

Developer implementation responsibilities:
- build map UI and chart rendering
- fetch and parse API responses in application code
- build the before-and-after image comparison interface
- process downloaded geospatial scenes
- implement filters, chart labels, and metadata display

This project currently has data collection work complete for climate context and significant documentation for satellite access, but real Landsat image retrieval and image processing remain pending.
