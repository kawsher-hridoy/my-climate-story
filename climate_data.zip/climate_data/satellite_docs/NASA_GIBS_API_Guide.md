# NASA GIBS API Guide

## Purpose
This guide summarizes official NASA GIBS (Global Imagery Browse Services) access methods and usage points for beginner developers. It is intended to support project planning, not to replace the official documentation.

## Verified source
Official GIBS access documentation: https://nasa-gibs.github.io/gibs-api-docs/access-basics/

## What GIBS is
NASA GIBS provides public web-accessible imagery layers using standards-based APIs. The official documentation states that GIBS visualizations are available through public standards-compliant web services hosted on the gibs.earthdata.nasa.gov domain.

## Official API endpoints
The official documentation describes GIBS as being accessed through service endpoints that depend on the service and the map projection.

Common examples from the official service patterns:

- WMTS endpoint pattern:
  - https://gibs.earthdata.nasa.gov/wmts/epsg4326/wmts.cgi
  - https://gibs.earthdata.nasa.gov/wmts/epsg3857/wmts.cgi
- WMS endpoint pattern:
  - https://gibs.earthdata.nasa.gov/wms/epsg4326
  - https://gibs.earthdata.nasa.gov/wms/epsg3857

These are examples of the public service locations; exact endpoint details may differ by projection and service.

## Access methods
### 1. WMTS (Web Map Tile Service)
WMTS is the tile-based method generally used for web map display. It is suitable for map tiles and browser-based map layers.

Typical WMTS request parameters include:
- SERVICE=WMTS
- REQUEST=GetTile
- VERSION=1.0.0
- LAYER
- STYLE
- TILEMATRIXSET
- TILEMATRIX
- TILEROW
- TILECOL
- FORMAT

### 2. WMS (Web Map Service)
WMS is used for map images and can be useful for retrieving a rendered map image rather than tile-based browsing.

Typical WMS parameters include:
- service=WMS
- request=GetMap
- version=1.1.1
- layers
- bbox
- width
- height
- srs
- format

## Suitable imagery layers
GIBS provides many NASA imagery products, but not all are meant to replace a Landsat archive or a custom analysis workflow. Some commonly used categories from the NASA GIBS ecosystem include:

- MODIS corrected reflectance layers
- VIIRS corrected reflectance layers
- Daily or composite Earth observation products
- other NASA Earth science visualization layers

Examples of layer identifiers used in GIBS examples include:
- MODIS_Terra_CorrectedReflectance_TrueColor
- MODIS_Aqua_CorrectedReflectance_TrueColor
- VIIRS_SNPP_CorrectedReflectance_TrueColor

Important: layer IDs are product-specific and may change over time. Exact availability and date coverage must be checked in the official GIBS layer catalog or metadata for the specific layer being used.

## Historical date ranges
GIBS is designed for public visual layers and imagery access. The documentation does not imply that every GIBS layer has a continuous archive dating back to the 1980s.

Verified fact from the official GIBS docs:
- GIBS has time-enabled layers and service-based access, but date availability is layer-specific.
- A layer may have recent composites, daily imagery, or limited historical coverage depending on the product.

Unverified detail to confirm for each project layer:
- whether a selected layer covers Bangladesh for a chosen year or season
- whether the layer is suitable for long-term urban change detection before 2000

## Supported map projections
The official documentation states that services are accessed through endpoints specific to the service and map projection. Examples shown in public docs include:

- EPSG:4326
- EPSG:3857

This means developers should verify which projection the layer supports before integrating it into a mapping client.

## Tile formats and resolutions
The official GIBS docs describe images as pre-determined resolutions and discuss map tiles. Typical web visualization formats are:

- image/png
- image/jpeg

For web map displays, GIBS usually serves pre-rendered tiles rather than raw analysis-ready geospatial rasters for large scientific processing workflows.

## Leaflet integration
Developers can integrate GIBS imagery into Leaflet by using a tile layer URL that points to a supported GIBS WMTS/WMS endpoint.

Example concept:

```javascript
const tileLayer = L.tileLayer(
  'https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/{layer}/default/{time}/EPSG3857_250m/{z}/{y}/{x}.jpg',
  {
    layer: 'MODIS_Terra_CorrectedReflectance_TrueColor',
    time: '2024-01-01',
    attribution: 'NASA GIBS'
  }
);
```

Important notes:
- The exact template varies by projection and layer.
- Not every layer uses the same tile matrix or date pattern.
- The developer must verify the correct layer metadata before using a tile pattern in production.

## Best use for this project
GIBS is useful for:
- quick basemap visualization
- browser-friendly NASA imagery layers
- recent or near-real-time global products

GIBS is not the primary source for a detailed historical Landsat time-series workflow for Bangladesh cities or wetlands. For that requirement, the official USGS Landsat archive is more appropriate.

## Verification status
This summary is based on the official NASA GIBS documentation and is considered verified where directly stated. Layer-specific coverage, exact historical dates, and tile templates for a chosen product must still be verified in the product metadata.
