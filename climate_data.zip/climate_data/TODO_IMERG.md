# TODO: rainfall from GPM IMERG (replaces POWER PRECTOTCORR for trends)
1. https://giovanni.gsfc.nasa.gov  (log in with free Earthdata account)
2. Plot type: Time Series, Area-Averaged
3. Variable: search "IMERG monthly precipitation"
4. Dates: 2001-01 to 2025-12
5. Area: small box around each city (use Locations.csv, about +-0.25 degrees)
6. Download CSV. One file per location (11 locations; skip Bhola). Save into `imerg/` as `IMERG_<location>.csv`.
7. Run the same Theil-Sen + Mann-Kendall on annual means. Menu names may differ: search "IMERG".
If time is short: drop rainfall trend claims, show rainfall descriptively only.
