import csv
from pathlib import Path
from datetime import datetime

BASE = Path(__file__).resolve().parent
INPUT = BASE / "downloaded_data" / "Bangladesh_Monthly_Climate_Data.csv"
OUTPUT_DIR = BASE / "cleaned_data"
OUTPUT_DIR.mkdir(exist_ok=True)

MONTHLY_FILE = OUTPUT_DIR / "Bangladesh_Clean_Monthly_Data.csv"
ANNUAL_FILE = OUTPUT_DIR / "Bangladesh_Annual_Summary.csv"
REPORT_FILE = OUTPUT_DIR / "Data_Quality_Report.txt"

PARAMETERS = ["T2M", "T2M_MAX", "T2M_MIN", "PRECTOTCORR", "RH2M"]
monthly_rows = []
annual_rows = []
missing_count = {p: 0 for p in PARAMETERS}
invalid_dates = 0

def clean_value(value, parameter):
    value = (value or "").strip()
    if value == "":
        missing_count[parameter] += 1
        return ""
    try:
        number = float(value)
        if number <= -999:
            missing_count[parameter] += 1
            return ""
        return number
    except ValueError:
        missing_count[parameter] += 1
        return ""

with INPUT.open("r", encoding="utf-8-sig", newline="") as f:
    reader = csv.DictReader(f)
    for row in reader:
        date_code = row["year_month"].strip()
        if len(date_code) != 6 or not date_code.isdigit():
            invalid_dates += 1
            continue
        year = int(date_code[:4])
        month = int(date_code[4:])
        cleaned = {"location": row["location"], "latitude": row["latitude"], "longitude": row["longitude"], "year": year, "month": month}
        for p in PARAMETERS:
            cleaned[p] = clean_value(row.get(p), p)
        if 1 <= month <= 12:
            cleaned["date"] = f"{year}-{month:02d}-01"
            monthly_rows.append(cleaned)
        elif month == 13:
            annual_rows.append(cleaned)
        else:
            invalid_dates += 1

monthly_fields = ["location", "latitude", "longitude", "year", "month", "date", *PARAMETERS]
annual_fields = ["location", "latitude", "longitude", "year", "month", *PARAMETERS]

def save_csv(path, fields, rows):
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

save_csv(MONTHLY_FILE, monthly_fields, monthly_rows)
save_csv(ANNUAL_FILE, annual_fields, annual_rows)

report = [
    "NASA POWER DATA QUALITY REPORT",
    f"Generated: {datetime.now().isoformat()}",
    f"Monthly records: {len(monthly_rows)}",
    f"Annual records: {len(annual_rows)}",
    f"Invalid date records: {invalid_dates}",
    "",
    "Missing values by parameter:",
]
for p, count in missing_count.items():
    report.append(f"{p}: {count}")
report.extend(["", "Important notes:", "Monthly and annual records are separated.", "Missing values are stored as blank fields.", "PRECTOTCORR requires unit verification.", "Original NASA JSON and CSV files remain unchanged."])
REPORT_FILE.write_text("\n".join(report), encoding="utf-8")

print("DATA CLEANING COMPLETED!")
print(f"Monthly rows: {len(monthly_rows)}")
print(f"Annual rows: {len(annual_rows)}")
print(f"Invalid date rows: {invalid_dates}")
print("Files saved inside cleaned_data/")