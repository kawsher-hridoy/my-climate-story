"""My Climate Story - data fix. Usage: python3 fix_data.py <path to Bangladesh_Clean_Monthly_Data.csv>
Outputs (next to this script):
  Annual_Temperature_Trend_Ready.csv  - annual mean T2M, 2001-2025, Bhola removed (duplicate of Barishal)
  Break_Report.csv                    - detected level shift per location (T2M, PRECTOTCORR)
  Trend_Report_2001_2025.csv          - Theil-Sen slope/decade + Mann-Kendall p-value
"""
import csv, sys, math, statistics as st
from pathlib import Path
HERE = Path(__file__).resolve().parent
from collections import defaultdict

src = Path(sys.argv[1]) if len(sys.argv) > 1 else HERE.parent / "cleaned" / "Bangladesh_Clean_Monthly_Data.csv"
out = HERE.parent / "analysis_ready"
START, END = 2001, 2025

rows = list(csv.DictReader(src.open(encoding="utf-8-sig")))
ann = defaultdict(lambda: defaultdict(dict))          # loc -> year -> key -> list
for r in rows:
    for k in ("T2M", "PRECTOTCORR"):
        if r[k] != "":
            ann[r["location"]].setdefault(int(r["year"]), {}).setdefault(k, []).append(float(r[k]))

def annual(loc, key):
    return {y: st.mean(v[key]) for y, v in sorted(ann[loc].items()) if len(v.get(key, [])) == 12}

# Bhola == Barishal (same grid cell) -> keep only Barishal
if annual("Bhola", "T2M") == annual("Barishal", "T2M"):
    locs = [l for l in ann if l != "Bhola"]
else:
    locs = list(ann)

def theil_sen(xs, ys):
    return st.median((ys[j]-ys[i])/(xs[j]-xs[i]) for i in range(len(xs)) for j in range(i+1, len(xs)))

def mann_kendall_p(ys):
    n = len(ys)
    s = sum((ys[j] > ys[i]) - (ys[j] < ys[i]) for i in range(n) for j in range(i+1, n))
    var = n*(n-1)*(2*n+5)/18
    z = 0 if s == 0 else (s-1)/math.sqrt(var) if s > 0 else (s+1)/math.sqrt(var)
    return 2*(1-0.5*(1+math.erf(abs(z)/math.sqrt(2))))

def best_break(ys):
    """split point with largest mean difference in units of pooled std (simple level-shift check)"""
    best = (0, None)
    for k in range(6, len(ys)-6):
        a, b = ys[:k], ys[k:]
        sp = math.sqrt((st.pvariance(a)*len(a)+st.pvariance(b)*len(b))/len(ys)) or 1e-9
        d = abs(st.mean(a)-st.mean(b))/sp
        if d > best[0]: best = (d, k)
    return best

with (out/"Break_Report.csv").open("w", newline="") as f:
    w = csv.writer(f); w.writerow(["location","variable","break_year","mean_before","mean_after","shift_in_std_units","verdict"])
    for loc in locs:
        for key in ("T2M","PRECTOTCORR"):
            a = annual(loc, key); yrs = sorted(a); ys = [a[y] for y in yrs]
            d, k = best_break(ys)
            w.writerow([loc,key,yrs[k],round(st.mean(ys[:k]),2),round(st.mean(ys[k:]),2),round(d,2),
                        "LEVEL SHIFT - do not trend across it" if d > 1.5 else "ok"])

with (out/"Annual_Temperature_Trend_Ready.csv").open("w", newline="") as f:
    w = csv.writer(f); w.writerow(["location","year","T2M_annual_mean_C"])
    for loc in locs:
        for y, v in annual(loc, "T2M").items():
            if START <= y <= END: w.writerow([loc, y, round(v, 3)])

with (out/"Trend_Report_2001_2025.csv").open("w", newline="") as f:
    w = csv.writer(f); w.writerow(["location","variable","years","slope_per_decade","mann_kendall_p","note"])
    for loc in locs:
        for key in ("T2M","PRECTOTCORR"):
            a = {y: v for y, v in annual(loc, key).items() if START <= y <= END}
            yrs = sorted(a); ys = [a[y] for y in yrs]
            note = "" if key == "T2M" else "POWER rain has shifts - verify with GPM/IMERG before claiming"
            w.writerow([loc,key,f"{yrs[0]}-{yrs[-1]}",round(theil_sen(yrs,ys)*10,3),round(mann_kendall_p(ys),4),note])
print("done ->", out)
