# NASA POWER Data Units

Project: My Climate Story — NASA Space Apps Challenge

## Data Source

NASA POWER Monthly Point API

https://power.larc.nasa.gov/docs/services/api/

## Verified Parameters

| Parameter | Unit | Description |
|---|---|---|
| PRECTOTCORR | mm/day | Corrected precipitation |
| RH2M | % | Relative humidity at 2 meters |
| T2M | °C | Temperature at 2 meters |
| T2M_MAX | °C | Temperature at 2 meters maximum |
| T2M_MIN | °C | Temperature at 2 meters minimum |

## Developer Instructions

1. Temperature values use °C.
2. Relative humidity uses %.
3. PRECTOTCORR uses mm/day and must not be incorrectly labeled as monthly total rainfall.
4. Treat missing NASA POWER values as null.
5. Keep monthly records (01–12) separate from annual summaries (13).
6. Preserve the original NASA POWER JSON files.
7. Do not modify or delete CSV files.

## Source Verification

Units verified from the `parameters` metadata section of `NASA_POWER_dhaka.json` on November 7, 2026.

All five NASA POWER parameter units have been verified against the source JSON metadata.
