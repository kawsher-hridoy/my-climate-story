# climate_data — My Climate Story (NASA Space Apps 2026, Challenge: Earth System Trend Detective)

## Start here (what to use)
| Need | File |
|---|---|
| Temperature trend (use this) | `analysis_ready/Annual_Temperature_Trend_Ready.csv` (annual mean T2M, 2001-2025, 11 locations) |
| Trend numbers (slope/decade, Mann-Kendall p) | `analysis_ready/Trend_Report_2001_2025.csv` |
| Where data jumps (do not trend across) | `analysis_ready/Break_Report.csv` |
| Monthly data (all years, cleaned) | `cleaned/Bangladesh_Clean_Monthly_Data.csv` (months 1-12 only) |
| Annual means from NASA (month 13) | `cleaned/Bangladesh_Annual_Summary.csv` |
| Original NASA files (never edit) | `raw_nasa_power/` |
| Global context | `global_gistemp/` |
| Location coordinates | `Locations.csv` |

## Units
T2M, T2M_MAX, T2M_MIN: °C. RH2M: %. PRECTOTCORR: **mm/day** (not monthly total).

## Known data issues (read before using)
1. **Level shift ~1997-2000 in temperature.** Dhaka falls ~0.8 °C across it; same year in most cities. Not climate. -> Trend only from **2001**.
2. **Rainfall (PRECTOTCORR) roughly doubles around 2015-2016 in almost every city.** POWER rainfall must NOT be used for trends. -> Replace with GPM IMERG monthly (see `TODO_IMERG.md`), or show rainfall only descriptively.
3. **Bhola = Barishal** (identical values, same grid cell). Bhola is excluded from analysis files. Keep Bhola for satellite images only.
4. Break detection is a simple screening (largest mean shift), not a formal test. Verify against NASA POWER / MERRA-2 documentation.
5. 2001-2025 is only 25 years: most temperature trends are NOT significant (Cox's Bazar: +0.17 °C/decade, p=0.0035 is the exception). Say so on the site.
6. Landsat/satellite scenes: **not verified or downloaded** (see `satellite_docs/`, status PENDING). NASA GIBS imagery works without download.

## Re-run
```
python3 scripts/fix_data.py     # rebuilds analysis_ready/ from cleaned/ (Python 3, no extra packages)
```
Data source: NASA POWER Monthly API v2.10.0 (downloaded 7 Nov 2026), NASA GISTEMP v4.
