# Missing Data Checklist

## 1) Missing but required for the project

### A. Verified Landsat imagery scenes
The project still lacks real, authenticated Landsat scene records for:

- Dhaka
- Satkhira
- Sunamganj
- Bhola

Required metadata for each scene:
- Location name
- Latitude and longitude
- Satellite name
- Sensor name
- Product identifier
- Collection and processing level
- Acquisition date
- WRS path and row
- Scene cloud cover percentage
- Spatial resolution
- Official source URL
- Verification status

### B. Downloaded image files
Not yet available:
- actual Landsat image files for selected dates
- processed subsets for each study area
- before/after comparison imagery stack

### C. Scene-level historical comparisons
Not yet available:
- one verified historical scene for each target location
- one verified recent scene for each target location
- matched seasonal windows for comparable imagery

## 2) Conditions to consider before marking a scene as usable
A scene should only be used when all of the following are known:

- the official USGS or NASA source is identified
- the scene was actually retrieved from an authoritative archive
- the acquisition date is confirmed
- the product level and collection are confirmed
- cloud cover is recorded and acceptable
- date and season are suitable for comparison

## 3) Checklist for remaining data collection tasks
- [ ] Authenticate to USGS EarthExplorer or M2M API
- [ ] Search for Landsat Collection 2 scenes near Dhaka
- [ ] Search for Landsat Collection 2 scenes near Satkhira
- [ ] Search for Landsat Collection 2 scenes near Sunamganj
- [ ] Search for Landsat Collection 2 scenes near Bhola
- [ ] Check cloud cover and seasonal comparability
- [ ] Record historical and recent candidate scenes
- [ ] Keep only scene metadata from authoritative records
- [ ] Reject any unverified or guessed scene information
- [ ] Download only chosen, real scenes for later processing
- [ ] Label all outputs as VERIFIED, UNVERIFIED, or PENDING

## 4) Important scientific caution
Do not treat a scene as available just because a similar product exists in the archive. A location-specific date must be searched, retrieved, and documented before it can be used in the project.

## 5) Current manager-facing status
Current data collection status is:

- Climate data: mostly complete
- Global climate context: complete
- Verified Landsat imagery: not yet available
- Imagery-driven before/after feature: pending archive access
