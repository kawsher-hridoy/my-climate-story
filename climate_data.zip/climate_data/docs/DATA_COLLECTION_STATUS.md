# Data Collection Status

## Executive summary
The project has completed a substantial data-collection phase for local climate data and global climate context. The main incomplete area is verified satellite imagery acquisition for Bangladesh-specific historical and recent Landsat scenes.

## Status summary

| Area | Status | Notes |
|---|---|---|
| Bangladesh location list | COMPLETE | `Locations.csv` contains 12 city/area coordinates |
| NASA POWER raw data | COMPLETE | JSON files downloaded for each study location |
| NASA POWER monthly cleaned data | COMPLETE | `Bangladesh_Clean_Monthly_Data.csv` prepared |
| NASA POWER annual summary | COMPLETE | `Bangladesh_Annual_Summary.csv` prepared |
| NASA POWER parameter unit validation | COMPLETE | `NASA_Data_Units.md` updated with verified units |
| Global GISTEMP raw file | COMPLETE | `Global_Temperature_Data_GISTEMP.csv` present |
| Global GISTEMP processed outputs | COMPLETE | Annual and monthly clean CSVs generated |
| Data quality documentation | COMPLETE | Quality reports exist for POWER and GISTEMP |
| Official API/source links | COMPLETE | `API_Links.txt` contains NASA and USGS references |
| NASA GIBS documentation | COMPLETE | Guide present in `satellite_data/` |
| Landsat research documentation | COMPLETE | Guides and validation notes created |
| Real Landsat scene verification | PENDING | No genuine scene metadata has been verified |
| Landsat scene download | PENDING | Not yet started |
| Bangladesh before/after imagery dataset | PENDING | Requires authenticated USGS archive access |

## Verified collection outcomes
### Climate data
- NASA POWER monthly point data was collected for multiple Bangladesh locations.
- Cleaned monthly and annual CSVs are available.
- Parameter units have been verified against the original NASA JSON metadata.
- GISTEMP global anomaly data has been collected and processed.

### Documentation
- Official NASA and USGS references are documented.
- Data quality notes and developer guides exist.
- Scientific caveats are included, including the fact that GISTEMP is not local Bangladesh temperature.

## Incomplete or pending work
### Real Landsat imagery
The following items remain pending and must be marked clearly as such:

- authenticated USGS EarthExplorer access
- scene search for Dhaka, Satkhira, Sunamganj, and Bhola
- scene metadata retrieval with cloud cover and path/row
- actual before-and-after image download
- local geospatial processing and comparison

This is not a data-quality failure of the climate datasets; it is a current limitation in the satellite imagery acquisition step.

## Scientific accuracy note
The project is scientifically ready for:
- local power-based climate summaries
- global anomaly context
- developer-ready documentation of climate data units and quality

The project is not scientifically ready for:
- definitive before-and-after image-based change claims
- location-specific Landsat analysis without verified scene metadata

## Recommended next assignment
Assign the following tasks to the developer team after data collection is complete:

1. authenticate to USGS archive access
2. search for verified Landsat scenes at each Bangladesh location
3. download only chosen scenes
4. process the selected imagery and compare before/after dates
5. ensure all output is labeled with official source attribution and cloud-cover context
