"""
My Climate Story - NASA data downloader
Run: python download_climate_data.py
Requires: Python 3.9+ and internet access. No API key is required for these public endpoints.
Downloads:
  - NASA POWER monthly point JSON + flattened CSV for each location
  - NASA GISTEMP global monthly CSV
  - Dhaka POWER response copied as Sample_NASA_POWER_Data.json
"""
from pathlib import Path
import csv, json, time, urllib.request, urllib.error

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "downloaded_data"
OUT.mkdir(exist_ok=True)

START_YEAR = 1981
END_YEAR = 2025  # Use complete years for a stable first comparison.
PARAMETERS = "T2M,T2M_MAX,T2M_MIN,PRECTOTCORR,RH2M"
COMMUNITY = "AG"
POWER_URL = (
    "https://power.larc.nasa.gov/api/temporal/monthly/point"
    "?parameters={parameters}&community={community}"
    "&longitude={lon}&latitude={lat}&start={start}&end={end}&format=JSON"
)
GISTEMP_URL = "https://data.giss.nasa.gov/gistemp/tabledata_v4/GLB.Ts+dSST.csv"

def download(url):
    req = urllib.request.Request(url, headers={"User-Agent": "MyClimateStoryStudentProject/1.0"})
    with urllib.request.urlopen(req, timeout=90) as response:
        return response.read()

def flatten_power(payload, location_name, latitude, longitude):
    props = payload.get("properties", {})
    parameter_data = props.get("parameter", {})
    # NASA POWER monthly keys generally look like YYYYMM; each parameter is a dictionary.
    keys = sorted(set().union(*(set(v.keys()) for v in parameter_data.values() if isinstance(v, dict))))
    rows = []
    for key in keys:
        row = {
            "location": location_name,
            "latitude": latitude,
            "longitude": longitude,
            "year_month": key,
        }
        for param, values in parameter_data.items():
            if isinstance(values, dict):
                row[param] = values.get(key, "")
        rows.append(row)
    return rows

def main():
    locations_file = ROOT / "Locations.csv"
    with locations_file.open(encoding="utf-8-sig", newline="") as f:
        locations = list(csv.DictReader(f))

    all_rows = []
    for loc in locations:
        name = loc["location_name"]
        lat, lon = float(loc["latitude"]), float(loc["longitude"])
        url = POWER_URL.format(
            parameters=PARAMETERS, community=COMMUNITY, lon=lon, lat=lat,
            start=START_YEAR, end=END_YEAR
        )
        safe_name = name.lower().replace(" ", "_").replace("'", "")
        print(f"Downloading NASA POWER monthly data: {name} ...")
        try:
            raw = download(url)
            payload = json.loads(raw.decode("utf-8"))
            (OUT / f"NASA_POWER_{safe_name}.json").write_text(
                json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
            )
            rows = flatten_power(payload, name, lat, lon)
            all_rows.extend(rows)
            if name == "Dhaka":
                (ROOT / "Sample_NASA_POWER_Data.json").write_text(
                    json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
                )
            print(f"  Saved {len(rows)} monthly records.")
        except Exception as e:
            print(f"  ERROR for {name}: {e}")
        time.sleep(1)  # Be polite to the public API.

    if all_rows:
        fields = list(dict.fromkeys(k for row in all_rows for k in row.keys()))
        with (OUT / "Bangladesh_Monthly_Climate_Data.csv").open("w", newline="", encoding="utf-8-sig") as f:
            writer = csv.DictWriter(f, fieldnames=fields)
            writer.writeheader()
            writer.writerows(all_rows)
        print(f"\nSaved combined CSV: {len(all_rows)} rows")

    print("\nDownloading NASA GISTEMP global monthly CSV ...")
    try:
        raw = download(GISTEMP_URL)
        (OUT / "Global_Temperature_Data_GISTEMP.csv").write_bytes(raw)
        print("Saved GISTEMP CSV.")
    except Exception as e:
        print("GISTEMP download failed:", e)
        print("Download manually from the NASA GISTEMP Data Downloads page (link in API_Links.txt).")

    print("\nDone. Check the downloaded_data folder and Sample_NASA_POWER_Data.json.")

if __name__ == "__main__":
    main()
