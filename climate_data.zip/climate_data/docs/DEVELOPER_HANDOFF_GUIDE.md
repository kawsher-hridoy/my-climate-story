# Developer Handoff Guide

## Purpose
This guide explains what data is ready for the developer team and which project tasks still require real archive access or implementation work.

## Data collection responsibilities
The data collection team is responsible for:

- collecting valid raw source files
- checking metadata quality and units
- validating date formatting and missing data handling
- documenting source limitations
- preserving original NASA data files unchanged
- preparing cleaned CSVs and quality reports for handoff

## Developer implementation responsibilities
The developer team is responsible for:

- building the map interface
- using the location coordinates from `Locations.csv`
- querying NASA POWER and rendering chart visuals
- displaying GISTEMP anomaly context in the app
- building the before-and-after imagery interface once real Landsat scenes are verified
- processing geospatial files and handling no-data or cloud-masked images

## Datasets ready for app use
### 1. Location selection data
Use: `Locations.csv`
- Input for map selection
- Approximate city-center coordinates for 12 Bangladesh places
- Not an official boundary dataset

### 2. NASA POWER local climate data
Use: `cleaned_data/Bangladesh_Clean_Monthly_Data.csv` and `cleaned_data/Bangladesh_Annual_Summary.csv`
- This is the main dataset for local climate analysis.
- Recommended for charts of temperature, rainfall, humidity, and extremes.
- Use the verified units from `NASA_Data_Units.md`.

### 3. GISTEMP global context data
Use: `gistemp_processed/Global_Temperature_Annual_Clean.csv` and `gistemp_processed/Global_Temperature_Monthly_Clean.csv`
- This is for the global temperature anomaly context chart.
- Do not present it as local Bangladesh temperature.

### 4. Source reference files
Use:
- `API_Links.txt`
- `NASA_Data_Units.md`
- `README.md`
- `satellite_data/*.md` and `Satellite_Data_Sources.csv`

## Data still requiring developer or archive access
### Landsat imagery
The actual before-and-after imagery feature is not ready because:

- no verified Landsat scene metadata has been acquired
- no real Landsat scene download has yet been performed
- no real image processing has taken place

### Required next step
The team should:

1. authenticate to USGS EarthExplorer or the M2M API
2. search for Bangladesh Landsat scenes near Dhaka, Satkhira, Sunamganj, and Bhola
3. select scenes by date, season, and cloud cover
4. store the verified metadata in `satellite_data/Bangladesh_Landsat_Scene_Catalog.csv`
5. download and process only the scenes selected for comparison

## Feature-to-dataset mapping
| Planned feature | Recommended dataset | Status |
|---|---|---|
| User selects location on map | `Locations.csv` | Ready |
| Local temperature trend chart | `cleaned_data/Bangladesh_Clean_Monthly_Data.csv` | Ready |
| Local annual climate summary | `cleaned_data/Bangladesh_Annual_Summary.csv` | Ready |
| Global temperature anomaly chart | `gistemp_processed/Global_Temperature_Annual_Clean.csv` | Ready |
| Before-and-after satellite imagery | Real Landsat scenes from USGS archive | Pending |
| Map display with NASA GIBS tiles | NASA GIBS layer docs and official service references | Documented, not yet scene-verified |

## Important warnings for developers
- Do not present GISTEMP as Bangladesh temperature.
- Do not treat approximate location coordinates as precise admin boundaries.
- Do not plot a value with missing NASA POWER data as a real number.
- Do not claim climate change from imagery without a verified scene and documented comparison window.
- Do not fabricate scene metadata or cloud cover values.

## Final handoff status
The project is ready for:
- local climate data charting
- global anomaly context
- map-based user experience planning

The project is not ready for:
- confident Landsat before-and-after image claims
- final remote-sensing feature implementation without verified archive access

The correct way to proceed is to keep the climate data collection done and treat real Landsat imagery as deliberately pending until archive access is obtained and actual metadata is recorded.
