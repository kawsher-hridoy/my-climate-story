# NASA GISTEMP Developer Guide

## 1) What NASA GISTEMP is
NASA GISTEMP (Goddard Institute for Space Studies Surface Temperature Analysis) is NASA's long-running global temperature analysis. It combines land and ocean temperature observations to estimate a global temperature anomaly series over time. The dataset is widely used to track long-term warming trends.

## 2) What temperature anomaly means
A temperature anomaly is the difference between the observed temperature and a reference baseline. It is not the same as an actual temperature reading in °C. For example, a value of +0.8 means the observed global temperature was 0.8 °C warmer than the chosen baseline. Negative values indicate cooler-than-baseline conditions.

## 3) Baseline period
The official NASA GISTEMP baseline period is 1951–1980. The dataset in this project compares current observations against that reference period.

## 4) Building a global temperature anomaly line chart with Chart.js
```javascript
const response = await fetch('./Global_Temperature_Annual_Clean.csv');
const text = await response.text();
const rows = text.trim().split('\n').slice(1);
const labels = [];
const values = [];
for (const row of rows) {
  const [year, anomaly] = row.split(',');
  labels.push(Number(year));
  values.push(Number(anomaly));
}
new Chart(document.getElementById('chart'), {
  type: 'line',
  data: {
    labels,
    datasets: [{
      label: 'Global Temperature Anomaly (°C)',
      data: values,
      borderColor: '#2563eb',
      fill: false,
      tension: 0.15
    }]
  },
  options: {
    responsive: true,
    scales: {
      x: { title: { display: true, text: 'Year' } },
      y: { title: { display: true, text: 'Temperature Anomaly (°C)' } }
    },
    plugins: {
      title: { display: true, text: 'Global Temperature Anomaly Relative to 1951–1980 Baseline' }
    }
  }
});
```

## 5) CSV columns developers should use
For annual analysis, use:
- `year`
- `temperature_anomaly_c`

For monthly analysis, use:
- `year`
- `month`
- `date`
- `temperature_anomaly_c`

Do not use the seasonal columns (`DJF`, `MAM`, `JJA`, `SON`) for monthly trend analysis because they are three-month seasonal summaries, not single-month records.

## 6) Correct graph title, axes, and units
Use these conventions:
- Chart title: `Global Temperature Anomaly Relative to 1951–1980 Baseline`
- X-axis: `Year`
- Y-axis: `Temperature Anomaly (°C)`
- Data values: °C anomaly, not absolute temperature
- Annual output is stored in `Global_Temperature_Annual_Clean.csv`
- Monthly output is stored in `Global_Temperature_Monthly_Clean.csv`

## 7) Why this must not be presented as local Bangladesh temperatures
This dataset is a global land-ocean anomaly series. It does not represent Bangladesh-only temperatures or city-level climate conditions. The values describe how the planetary mean differs from the baseline, not local conditions in Dhaka, Khulna, or any other region. Developers should not plot these values as if they were Bangladesh temperature readings.

## 8) Official NASA data source URL
Official NASA data source: https://data.giss.nasa.gov/gistemp/

The source file used in this project is: `downloaded_data/Global_Temperature_Data_GISTEMP.csv`

## 9) Collection and processing dates
- Original NASA CSV inspection and validation: 2026-11-07
- Cleaned derivative files generated: 2026-11-07
- Original NASA source file preserved unchanged: Yes

## Final note
All processed files in this folder were built only from the verified NASA GISTEMP values in the original CSV. Missing values were left missing and were not replaced with zero or estimated values.
