# Satellite Comparison Plan

## Purpose
This plan explains how to prepare a credible before-and-after comparison for historical satellite imagery in Bangladesh once archive access is available.

## Current status
At the time of this documentation, no real Landsat scene metadata has been retrieved from the authoritative USGS archive. That means the project is not yet ready to download or compare actual scenes for Dhaka, Satkhira, Sunamganj, or Bhola.

## Study area coordinates
The project uses approximate center coordinates from the existing location file:

| Location | Latitude | Longitude |
|---|---:|---:|
| Dhaka | 23.8103 | 90.4125 |
| Satkhira | 22.7185 | 89.0705 |
| Bhola | 22.6859 | 90.6482 |
| Sunamganj | 25.0658 | 91.3950 |

## Recommended archive workflow
Once authenticated access is available, the workflow should be:

1. Use USGS EarthExplorer or the M2M API to search Landsat Collection 2 scenes for each study area.
2. Filter by location and acquisition date.
3. Prefer a historical date range around 1985-1995 and a recent range around 2020-2025.
4. Prefer Level-2 Surface Reflectance when available.
5. Filter for low cloud cover, ideally below 20% scene cloud cover.
6. Choose comparable seasons for before-and-after comparisons.
7. Record the exact metadata for each selected scene.
8. Download only the scenes needed for the project.

## How to use the metadata
Each selected scene should be evaluated against the following fields:

- Location name
- Latitude and longitude
- Satellite name
- Sensor name
- Product identifier
- Collection and processing level
- Acquisition date
- WRS path and row
- Cloud cover
- Spatial resolution
- Official source URL
- Verification status

These values are essential for a reliable comparison. A scene without valid metadata should not be used in the project.

## Displaying before-and-after imagery
After scene selection and download, the workflow should be:

1. Add the historical scene and recent scene to the local project folder.
2. Confirm the coordinate system and projection.
3. Subset the imagery to the area of interest.
4. Use a simple visual comparison or map display using a browser or GIS tool.
5. Label each image with date, location, sensor, and product metadata.

Do not present a scene as a verified before-and-after pair unless the actual scene records and dates have been retrieved and recorded.

## Handling missing imagery
If a scene is missing or cloud-covered:

- record it as missing or unsuitable
- do not estimate or invent a replacement image
- do not hide the gap in the study design
- choose a different date or a different season that matches the project criteria

## Why date, season, cloud cover, and sensor differences matter
These factors directly affect image comparability:

- Date determines whether the scene belongs to the historical or recent period.
- Season affects land-cover appearance, especially in wetlands and coastal areas.
- Cloud cover can obscure the ground surface.
- Sensor differences can change spectral response and band availability.

For Bangladesh, water, vegetation, and urban surfaces can change substantially between seasons; therefore, it is important to keep the comparison set as consistent as possible.

## Correct attribution
Any imagery used in the project must clearly attribute the official source, such as:

- NASA GIBS for browser-based web imagery layers
- USGS Landsat archive for historical scene data

The project should never imply that imagery is from a source it did not actually use.

## What still requires downloading and processing
The following tasks remain pending authentic scene acquisition:

- real Landsat scene selection for Dhaka
- real Landsat scene selection for Satkhira
- real Landsat scene selection for Sunamganj
- real Landsat scene selection for Bhola
- cloud filtering and date ordering
- scene download and local storage
- preprocessing and comparison visualization

## Final recommendation
Use the official USGS EarthExplorer or M2M API to search for scenes first. Only after a real scene is retrieved and recorded should the project proceed to download, process, and compare imagery.

Until that step is completed, the project must document the record as UNVERIFIED or NOT AVAILABLE rather than claiming a dataset exists.
