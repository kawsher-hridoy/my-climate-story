# Landsat Historical Data Guide

## Purpose
This document summarizes official USGS Landsat data access methods and explains which Landsat datasets are most suitable for historical before-and-after analysis in Bangladesh.

## Verified source
Official Landsat data access page: https://www.usgs.gov/landsat-missions/landsat-data-access
Also relevant: https://www.usgs.gov/landsat-missions/product-information

## What the USGS Landsat page confirms
The official USGS Landsat data access page states that:

- Landsat Level-1 scene-based products are available worldwide for Landsat 1-9.
- Landsat Level-2 scene-based surface reflectance and surface temperature products are available for Landsat 4-9.
- Landsat Collection 2 products are the current operational archive for analysis-ready products and scene-based access.
- Landsat data can be searched and downloaded via EarthExplorer, the Machine-to-Machine API, AWS cloud access, and bulk download pathways.

These are verified official USGS statements.

## Historical coverage
The Landsat archive is the most important official historical satellite source for this project. The archive is much more appropriate than GIBS for a before-and-after feature because it supports scene-based search by date and location.

Verified constraints from official USGS materials:
- Landsat data products are organized by mission and collection (for example, Landsat Collection 2).
- Historical coverage depends on the sensor and product type.
- Not every product or sensor covers the same years or the same spatial/temporal extent.

General historical context:
- Landsat 1 launched in 1972.
- Landsat 8 launched in 2013.
- Landsat 9 launched in 2021.

These dates are widely documented by the Landsat program and are consistent with the historical mission timeline. For project work, the key point is that official Landsat archive access exists from the early 1970s onward, but the exact date for a scene depends on the catalog and cloud conditions.

## Suitable datasets for Bangladesh project cases
### 1. Dhaka urban expansion
Best source for this use case:
- Landsat Collection 2 Level-2 surface reflectance scenes
- Search by area of interest and date range using EarthExplorer or the M2M API

Why it is suitable:
- It provides repeated historical imagery for urban growth and land-use change.
- It supports scene-based comparison over time.
- It is more appropriate than GIBS for detecting land-cover change.

### 2. Satkhira coastal landscape changes
Best source for this use case:
- Landsat Collection 2 Level-2 or Level-1 scenes
- Use dates in dry-season windows where cloud cover is lower and the coastline is easier to interpret.

Why it is suitable:
- Coastal geography is highly sensitive to seasonal variation.
- Landsat scenes can be compared across years and seasons.

### 3. Sunamganj wetland changes
Best source for this use case:
- Landsat Collection 2 Level-2 surface reflectance
- Multi-date moderate-resolution imagery for wetland extent and water-body changes

Why it is suitable:
- Wetland analysis depends on consistent seasonal windows and cloud-free scenes.
- Landsat's repeated archive supports multi-year comparison.

### 4. Bhola river and coastal changes
Best source for this use case:
- Landsat Collection 2 Level-2 or Level-1 scenes
- Time-series analysis across multiple years

Why it is suitable:
- Riverbank and coastal morphology often require repeated historical imagery across several years.

## Cloud cover and seasonal consistency
The official USGS pages describe available Landsat products and access methods, but cloud cover is not a fixed property of the archive. It varies by scene and season.

For Bangladesh, the following practical guidance is important:
- The monsoon season may produce heavy cloud cover and make land-cover comparisons harder.
- Dry-season imagery is typically easier for before-and-after comparisons.
- Seasonal consistency matters: a wet-season scene and a dry-season scene are not directly comparable without careful interpretation.

This is a project planning note, not a guarantee of cloud-free coverage for any specific scene date.

## Spatial resolution and sensor differences
USGS Landsat product pages describe multiple Landsat products and missions. The general pattern is:

- Landsat multispectral products are typically around 30 m resolution for the common optical bands.
- Landsat thermal products have different resolution values depending on sensor.
- Panchromatic imagery may have finer spatial detail, but it is not always the best choice for all land-cover work.
- Sensor differences across Landsat 1-3, 4-5, 7, 8, and 9 affect spectral bands and historical continuity.

Important: project developers should confirm the exact sensor and product for the chosen scene and date. The archive is not one single uniform sensor across all years.

## Recommended official access tools
The official USGS page lists the following tools:

- EarthExplorer
- M2M API
- Landsat Commercial Cloud Data Access (AWS / STAC)
- Bulk Download Web Application
- GloVis
- ESPA

For a beginner-friendly workflow in this project, the most practical official tools are:

1. EarthExplorer for visual scene search and download.
2. M2M API for scripted access and repeatable queries.
3. AWS cloud access for cloud-based Landsat data workflows.

## Best source for this project's before-and-after feature
The best official historical source for the project is:
- USGS Landsat Collection 2 Level-2 surface reflectance product accessed via EarthExplorer or the M2M API

This is preferred over GIBS because:
- it is scene-based
- it supports historical comparison by date and location
- it provides a more robust archive for change detection
- it aligns with the project goal of before-and-after comparisons across multiple years

## Verification status
Verified from official USGS pages:
- EarthExplorer is available for Landsat scene search and download.
- M2M API exists for scripting and dataset access.
- Landsat Collection 2 Level-1 and Level-2 products are official USGS products.
- Landsat data are available for historical and recent scenes, but exact scene availability for each Bangladesh location must be confirmed in the archive search tool.

Unverified details requiring additional scene-level checks:
- exact cloud cover for a selected Dhaka or coastal scene
- exact scene IDs for a chosen before-and-after pair
- exact historical availability for the specific project area and date window
