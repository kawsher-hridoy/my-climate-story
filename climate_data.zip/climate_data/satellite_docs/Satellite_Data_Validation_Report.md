# Satellite Data Validation Report

## Scope
This report summarizes the research and documentation completed for official NASA GIBS and USGS Landsat data sources relevant to the project.

## Verified facts
The following facts were verified from official NASA/USGS documentation:

- NASA GIBS exposes imagery through public standards-based web services.
- GIBS services use endpoints specific to the service and projection.
- Typical GIBS access methods include WMTS and WMS.
- GIBS is a web visualization service and not a full Landsat archive replacement.
- USGS EarthExplorer is a supported official data access application for Landsat products.
- USGS Landsat access includes Level-1 and Level-2 products for various Landsat missions.
- Landsat Collection 2 scene products are official USGS products for historical and recent imagery.
- Landsat data are available via EarthExplorer, M2M, AWS cloud access, and bulk download pathways.

## Unverified details requiring future scene-level checks
The following items are not yet fully verified for the exact Bangladesh locations in this project:

- exact scene IDs for Dhaka, Satkhira, Sunamganj, or Bhola
- exact cloud cover values for candidate scenes
- exact date windows available for every area of interest
- exact Landsat layer availability for specific before-and-after dates in Bangladesh

## Historical periods actually available
The project can state the following with confidence:

- Landsat archive access covers historical and recent imagery across multiple missions.
- The official Landsat program timeline extends from the 1970s into the present.
- The exact historical scene availability for a chosen Bangladesh place and date must be checked in the archive search tools.

For GIBS, we can state that:
- GIBS provides time-enabled, service-based imagery layers, but not all layers are available back to the 1980s.
- Historical layer availability is product-specific and must be verified for each layer.

## Best official sources for the project's before-and-after feature
Best source for historical comparison:
- USGS Landsat Collection 2 Level-2 scenes via EarthExplorer or M2M API

Best source for quick visualization:
- NASA GIBS layers for basemap-style imagery display

## Recommended approach
Use the official USGS Landsat archive for the actual before-and-after feature, and optionally use NASA GIBS for a general map background or quick interactive preview.

## Overall conclusion
This documentation distinguishes verified facts from scene-specific or product-specific details that still need confirmation. The safest and most defensible project approach is to rely on official USGS Landsat archive access for historical time-series work and treat GIBS as a supporting map visualization tool rather than the main historical analysis source.
